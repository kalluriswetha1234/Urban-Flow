# UrbanFlow — Localised Flood & Drainage Response

A beginner-friendly hackathon prototype based on the UrbanFlow presentation. It demonstrates:
- Dashboard counts for total, active, high-priority and resolved incidents
- Leaflet map with OpenStreetMap tiles and incident markers
- Incident reporting form
- Transparent illustrative priority score
- Municipal worker assignment and status tracking
- SQLite persistence

## Important demo limitations
- Seeded incidents and coordinates are **sample/demo data**, not verified live reports.
- Priority thresholds and scoring are illustrative, not validated municipal standards.
- The app does not currently use live rainfall data, IoT sensors, real municipal systems, authentication, or a photo upload service.
- OpenStreetMap tiles and Leaflet are loaded over the internet, so the map needs a connection.
- This is a hackathon prototype, not an emergency reporting service. Reports require human verification.

## 1. Install prerequisites
1. Install Python 3.10 or newer from https://www.python.org/downloads/
2. Install Visual Studio Code from https://code.visualstudio.com/
3. In VS Code, open the `UrbanFlow` folder.
4. Open Terminal → New Terminal.

Check Python:
```bash
python --version
```
On some systems, use `py --version` or `python3 --version`.

## 2. Create a virtual environment (recommended)

Windows:
```powershell
python -m venv .venv
.venv\Scripts\activate
```

If PowerShell blocks activation, you can use Command Prompt:
```bat
.venv\Scripts\activate.bat
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3. Install Flask
```bash
python -m pip install -r requirements.txt
```

## 4. Run the app
```bash
python app.py
```
If your system uses the Python launcher:
```powershell
py app.py
```

The terminal should show that the app is running. Open:
http://127.0.0.1:5000

Keep the terminal running while you use the website. Press `Ctrl+C` in the terminal to stop it.

## 5. Demo flow for judges
1. Show the dashboard and explain that seeded incidents are labelled SAMPLE.
2. Point out the map and the high/medium/low priority markers.
3. Submit a new incident. You can leave coordinates blank, or enter demo coordinates to place it on the map.
4. Explain the score: severity (0–5) + repeat reports (0–3) + impact (0–2), for a maximum of 10.
5. In Municipal task tracking, enter a worker name, set status to Assigned, and click Save update.
6. Change the same report to In Progress, save, then Resolved.
7. Show the updated counts and filter the task list by status.

## 6. Reset the demo data
Stop the app with `Ctrl+C`, then delete `urbanflow.db` from the project folder. Run `python app.py` again. The three sample incidents will be recreated.

## Project structure
```text
UrbanFlow/
├── app.py
├── requirements.txt
├── README.md
├── urbanflow.db          # created automatically when app.py starts
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── script.js
```

## API routes
- `GET /api/incidents` — incidents and dashboard stats
- `POST /api/incidents` — create incident
- `PATCH /api/incidents/<id>` — update worker assignment/status
- `GET /api/health` — basic health check
